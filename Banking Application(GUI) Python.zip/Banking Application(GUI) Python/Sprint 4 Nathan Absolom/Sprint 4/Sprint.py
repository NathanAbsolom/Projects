from os import name, system
from tkinter import *

import tkinter as tk
from tkinter import messagebox

from datetime import date
from datetime import time
from datetime import datetime
import re

Date_Time = ""

f = open("User_Details.txt",'r')

def depositFunction():
    depositAmount = depositEntry.get()
    username = userNameLog.get()
    Final_Amount = 0

    f = open("User_Details.txt",'r')

    info = f.read()
    info = info.split()
    f.close()
    if username in info:
        index = info.index(username) + 2
        previousAmount = info[index]

        if depositAmount.isnumeric() :
            Final_Amount = float(previousAmount) + float(depositAmount)
            f = open("User_Details.txt",'w')
            info[index] = str(Final_Amount)
            info = "\n".join(info)
            f.writelines(info)
            f.close()
            transaction_type = "Deposit"
            Date_Time = date.today()
            now = datetime.now()
            time_of_transaction = now.strftime("%H:%M:%S")
            file = open(username + "'s Transaction Log.txt" , "a")
            file.write("\nTransaction type :" + transaction_type + " \nDate of Transaction :" + str(Date_Time) +"\nTime of transaction :" +str(time_of_transaction) +    "\nDeposited Amount : R"+ str(depositAmount)  + "\nOld Amount : R" +  str(previousAmount) + "\n" + "New Amount : R" + str(Final_Amount))
            depositDisplay.insert(END,username ,  "You have deposited : R" + str(depositAmount) , "Your previous amount was : R " + str(previousAmount), "Your updated amount is : R " + str(Final_Amount) )  
        else:
            depositEntry.delete(0 , END)
            depositEntry.focus()
            return messagebox.showerror("Numeric", "Should only contain numeric values!")
            
def ViewBalance():
    f = open("User_Details.txt",'r')

    info = f.read()
    info = info.split()
    f.close()
   
    username = userNameLog.get()

    if username in info:
        index = info.index(username) + 2
        Current_Amount = info[index]
        ViewBalanceList.insert(END,username +  " your available balance is :   R "  + Current_Amount)

def WithdrawlFunction():
    withDrawlAmount = withdrawlEntry.get()
    username = userNameLog.get()
    Final_Amount = 0
   
    f = open("User_Details.txt",'r')
 
    info = f.read()
    info = info.split()
    f.close()
    if username in info:
        index = info.index(username) + 2
        previousAmount = info[index]
        if withDrawlAmount > previousAmount:
            messagebox.askretrycancel("Insufficient fund", "Please enter a valid amount")
            withdrawlEntry.focus()
            withdrawlEntry.delete(0, END)
        elif withDrawlAmount.isnumeric() :
            Final_Amount = float(previousAmount) - float(withDrawlAmount)
            f = open("User_Details.txt",'w')
            info[index] = str(Final_Amount)
            info = "\n".join(info)
            f.writelines(info)
            f.close() 
            transaction_type = "Withdrawl"
            Date_Time = date.today()
            now = datetime.now()
            time_of_transaction = now.strftime("%H:%M:%S")
            file = open(username + "'s Transaction Log.txt" , "a")
            file.write("\nTransaction type :" + transaction_type + "\nDate of Transaction :" + str(Date_Time) +"\nTime of transaction :" +str(time_of_transaction) + "\nAmount withdrawn : R"+ str(withDrawlAmount)  + "\nOld Amount : R" +  str(previousAmount) + "\n" + "New Amount : R" + str(Final_Amount))
            withdrawlDisplay.insert(END,username ,  "You have withdrawn : R" + str(withDrawlAmount) , "Your previous amount was : R " + str(previousAmount), "Your updated amount is : R " + str(Final_Amount) )            
        else:
            withdrawlEntry.delete(0, END)
            withdrawlEntry.focus()
            messagebox("Value","Should contain numerics only !")
            
def loginForm():
        root1.withdraw()
        
        global root  
        root = Tk()
        root.title("Login Form")
        root.geometry('300x300')
        root.config(bg='#8E8E8E')    
         
        display_label2 = Label(root,text ='Login',bg='#8E8E8E',fg='white',font=("Arial", 25))
        display_label2.pack()
        name_lbl2 = Label (root,text='Username',bg='#8E8E8E',fg='white')
        name_lbl2.pack()
       
        global userNameLog
        userNameLog = Entry(root)   
        userNameLog.pack()
              
        pass_lbl = Label(root, text="Password",bg='#8E8E8E',fg='white' )
        pass_lbl.pack()

        global passwordLog
        passwordLog = Entry(root , show="*")
        passwordLog.pack()

        btnConfirm = Button(root,borderwidth="4px" ,text="Confirm",height=3, width=10,bg="#F57513", command=Login)
        btnConfirm.pack(pady=15)
        btnBack = Button(root,borderwidth="4px" ,text="Back",height=3, width=10,bg="#F57513", command=LogreturnToMain)
        btnBack.pack(pady=15)

def returnToLogiin():
    ws1.withdraw()
    loginForm()

def registerForm():  
    root1.withdraw()
    global ws1
    ws1 = Tk()
    ws1.title('Register Form')
    ws1.geometry('450x400')
    ws1.config(bg='#8E8E8E')

    global name_tf
    global pin_ent
    global start_balance
    global confirmPassword

    name_tf = Entry(ws1)
    pin_ent = Entry(ws1,show="*",width=20)
    confirmPassword = Entry(ws1, show="*",width=20)
    start_balance = Entry(ws1)

    userName_lbl = Label(ws1,text ='Username :',bg='#8E8E8E',fg='white')

    display_label = Label(ws1,text ='Register Account',bg='#8E8E8E',fg='white',font=("Arial", 25))

    pin_lbl = Label(ws1,text='Enter Password :',bg='#8E8E8E',fg='white')
    confirmPassword_lbl = Label (ws1,text='Confirm Password :',bg='#8E8E8E',fg='white')

    Opening_Balance_lbl = Label(ws1,text='Enter Opening Balance',bg='#8E8E8E',fg='white')
    userNamebtn = Button(ws1,borderwidth="4px" ,  text="Confirm",height=3, width=10,bg="#F57513", command=RegisterAccount)
    LoginButton = Button(ws1,borderwidth="4px" , text="Login",height=3, width=10,bg="#F57513", command=returnToLogiin)

    display_label.pack()
    userName_lbl.pack()
    name_tf.pack()
    pin_lbl.pack()
    pin_ent.pack()
    confirmPassword_lbl.pack()
    confirmPassword.pack()
    Opening_Balance_lbl.pack()
    start_balance.pack()
    userNamebtn.pack(pady=15)
    LoginButton.pack(pady=15)

def ExitProgram():
    exit()
def mainForm():
    
    global root1
    root1 = Tk()    
    root1.title('Main Form')
    root1.geometry('300x200')
    root1.config(bg='#8E8E8E')
    headingLbl =Label(root1, text="Banking Solutions", font="Times" ,bg="#8E8E8E", )
    RegisterButton = Button(root1,borderwidth="4px", text="Register",height=3, width=15,bg="#F57513", command=registerForm)
    LoginButton  = Button(root1,borderwidth="4px", text="Login",height=3, width=15,bg="#F57513", command=loginForm)
    headingLbl.pack(pady=10)
    RegisterButton.pack(pady=10)
    LoginButton.pack(pady=10)
    
   
def RegisterAccount():  
     
    f = open("User_Details.txt",'r')
    info = f.read()
    name = name_tf.get()
    password = pin_ent.get()
    openingBalance = start_balance.get()
    passwordConfirm = confirmPassword.get()

    if name in info:
         messagebox.askretrycancel("Name Unavailable","Please Try different username")
         name_tf.delete(0 ,END)
         name_tf.focus()
    elif name.isalpha() == False:
            messagebox.askretrycancel("Username", "Should only contain alphabetic letters")
            name_tf.delete(0 ,END)
            name_tf.focus()
   
    
    elif password.isalpha() == True:  
        messagebox.askretrycancel("Password", "Should be numerics only")
        pin_ent.delete(0,END)
        pin_ent.focus()
    elif password.isnumeric() == False:
        messagebox.askretrycancel("Password", "Should not contain alphabetic characters")
        pin_ent.delete(0,END)
        pin_ent.focus()
    elif  len(password) != 4: 
        messagebox.askretrycancel("Password", "Should contain 4 digits only")
        pin_ent.delete(0,END)
        pin_ent.focus()

    elif passwordConfirm != password :
       messagebox.askretrycancel("Password", "Should be the same as the password entered first ")  
       confirmPassword.focus()
       confirmPassword.delete(0, END)

    elif openingBalance.isnumeric() == False:
        messagebox.askretrycancel("Opening Balance", "Should contain only numerics")
        start_balance.focus()
        start_balance.delete(0 ,END)
    else:         
        f = open("User_Details.txt",'a')
        info = "\n" + name + "\n" + password + "\n" + openingBalance
        f.write(info)
        print("Username : " + name + "\nPassword : " + password +"\nOpening Balance is : R" +  openingBalance)
        ws1.withdraw()  
        with open(name + "'s Transaction Log.txt", 'w') as f:
               loginForm()

def Options():
    root.withdraw()

    global root3
    root3 = Tk() 
    
    root3.title('Main Form')
    root3.geometry('450x400')
    root3.config(bg='#8E8E8E')

    View_Transaction_Button = Button(root3,borderwidth="4px" ,text="View Transactions",height=3, width=15,bg="#F57513", command=ViewTransactionForm )
    View_Balance_Button  = Button(root3,borderwidth="4px" ,text="View Balance",height=3, width=15,bg="#F57513", command= ViewBalanceForm)
    Deposit_Button =  Button(root3,borderwidth="4px", text="Deposit",height=3, width=15,bg="#F57513", command=depositForm )
    Withdrawal_Button = Button(root3,borderwidth="4px" ,text="Withdrawal",height=3, width=15,bg="#F57513",command=withdrawlForm )
    ExitButton = Button(root3,borderwidth="4px", text="Exit",height=3, width=15,bg="#F57513", command=ExitProgram)

    View_Transaction_Button.pack(pady=10)
    View_Balance_Button.pack(pady=10)
    Deposit_Button.pack(pady=10)
    Withdrawal_Button.pack(pady=10)
    ExitButton.pack(pady=10)

def DepReturnMain():
    root5.withdraw()
    Options()

def WithReturnMain():
    root6.withdraw()
    Options()

def LogreturnToMain():
    root.withdraw()
    mainForm()

def returnToOptions():
    root4.withdraw()
    Options()

def returnToOptionsFromViewBalance():
    root7.withdraw()
    Options()

def ViewTransactionForm():
    root3.withdraw()
    global DisplayTransaction
    global root4
    root4 = Tk() 
    
    root4.title('View Transactions')
    root4.geometry('700x700')
    root4.config(bg='#8E8E8E')

    DisplayTransaction = Listbox(root4, width=80, height=30)
    View_Button = Button(root4,borderwidth="4px",bg="#F57513" ,text="View Transactions", height=3 , width=18 ,command=ViewTransactions)
    backButton = Button(root4,borderwidth="4px",bg="#F57513" ,text="Back", height=3 , width=18 ,command=returnToOptions)
    
    DisplayTransaction.pack(pady=15)
    View_Button.pack(pady=15)
    backButton.pack(pady=15)

def ViewTransactions():
    DisplayTransaction.delete(0 ,END)
    username = userNameLog.get()
    file = open(username + "'s Transaction Log.txt")
    file.close()
    file2 = open(username + "'s Transaction Log.txt" , "r")

    for x in file2:           
        DisplayTransaction.insert(END,x)
  
def depositForm():
    root3.withdraw()
    global root5
    root5 = Tk()

    root5.title('Deposit Form')
    root5.geometry('500x500')
    root5.config(bg='#8E8E8E')
    global depositAmountlbl
    global depositEntry
    global depositDisplay

    depositAmountlbl = Label(root5, text="Enter amount you want to deposit :" ,bg='#8E8E8E',fg='white')
    depositEntry = Entry(root5)
    depositButton = Button(root5 ,borderwidth="4px" ,text="Deposit" ,height=1 , width=15, bg="#F57513" , command=depositFunction  )
    depositDisplay = Listbox(root5 , height=15 ,width=40)
    backButton = Button(root5 ,borderwidth="4px" ,text="Back" ,height=1 , width=15 ,bg="#F57513" , command= DepReturnMain )


    depositAmountlbl.pack(pady=10)
    depositEntry.pack(pady=10)
    depositButton.pack(pady=10)
    depositDisplay.pack(pady=10)
    backButton.pack(pady=10)

def withdrawlForm():
    root3.withdraw()

    global root6
    root6= Tk()

    root6.title('Withdrawl Form')
    root6.geometry('500x500')
    root6.config(bg='#8E8E8E')

    global withdrawlAmountlbl
    global withdrawlEntry
    global withdrawlDisplay

    withdrawlAmountlbl = Label(root6, text="Enter amount you want to withdraw :" ,bg='#8E8E8E',fg='white')
    withdrawlEntry = Entry(root6)
    withdrawlButton = Button(root6 ,borderwidth="4px" ,text="Withdraw" ,height=1 , width=15, bg="#F57513" , command=WithdrawlFunction )
    withdrawlDisplay = Listbox(root6 , height=15 ,width=40)
    backButton = Button(root6 ,borderwidth="4px" ,text="Back" ,height=1 , width=15, bg="#F57513" , command= WithReturnMain )
    withdrawlAmountlbl.pack(pady=10)
    withdrawlEntry.pack(pady=10)
    withdrawlButton.pack(pady=10)
    withdrawlDisplay.pack(pady=10)
    backButton.pack(pady=10)

def ViewBalanceForm():
    root3.withdraw()
    global root7
    root7= Tk()

    root7.title('View Form')
    root7.geometry('300x300')
    root7.config(bg='#8E8E8E')

    global backButton
    global ViewBalanceList
    
    ViewBalanceList = Listbox(root7, width=40, height=10)
    ViewButton = Button(root7,borderwidth="4px" ,text="View ", height=3 ,bg="#F57513" , width=10, command=ViewBalance)
    backButton = Button(root7, text="Back",borderwidth="4px" ,height=5 ,bg="#F57513" , width=10, command=returnToOptionsFromViewBalance)

    ViewBalanceList.pack(pady=10)
    ViewButton.pack(pady=5)
    backButton.pack(pady=5)

def Login():
    user_entered = userNameLog.get()
    password_entered = passwordLog.get()
  
    f = open("User_Details.txt",'r')
    info = f.read()
    info = info.split()
    if user_entered in info:
        index = info.index(user_entered) + 1
        usr_password = info[index]
        if usr_password == password_entered:
            Options()
        else:
            return messagebox.showerror("Password", "Incorrect Password")
    else:
        return messagebox.showerror("Name not found.",  "Please sign up if you are not a user.")

mainForm()
root1.mainloop()