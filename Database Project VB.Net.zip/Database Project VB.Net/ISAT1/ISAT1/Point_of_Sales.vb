﻿'Nathan Absolom (09)
'2017041486
Imports System.Data.OleDb
Imports System.IO

Public Class Point_of_Sales
    'Variable created to search for database file in the debug form
    Public DatabaseAddress As String = Directory.GetCurrentDirectory() & "\ISAT.accdb"
    'Declaring a variable to use for sql statements
    Public query As String
    'Declaring variables to use to get information from the database and store it into the variables
    Dim strProductName As String
    Dim ProductCode As String
    Dim ProductQty As Integer
    Dim ProductPrice As Decimal

    'Variables to use in calculation
    Public decSubT As Decimal
    Dim decAmount As Decimal
    Dim decAmount2 As Decimal
    'Variables created for user details
    Dim strName As String
    Dim strSurname As String

    'Variables to use in functions
    Dim VatAmount As Decimal
    Dim decDiscount As Decimal
    Dim Total As Decimal

    'Variables to assign to functions
    Dim decDiscountTotal As Decimal
    Dim decFinalAmount As Decimal
    Dim decVatTotal As Decimal


    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        'Hides current form
        Me.Hide()
        'Displays main menu form
        Main_Menu.Show()
        'Clears controls
        ClearControls()
    End Sub

    Private Sub btnPay_Click(sender As Object, e As EventArgs) Handles btnPay.Click
        'Declaring variables to use in calculations
        Dim Amountdue As Decimal
        Dim decChange As Decimal
        Dim decAmount2Pay As Decimal
        'Setting variable equal to the value entered in the textbox
        Amountdue = txtAmount.Text


        ' Variable declared to show a connection to the datasource
        Dim acc_Record As OleDbConnection
        acc_Record = New OleDbConnection
        'Type of access database application used
        acc_Record.ConnectionString = "Provider=Microsoft.ACE.OleDb.12.0;Data Source = " & DatabaseAddress

        'Setting variables equal to values from textboxes
        strName = txtName.Text
        strSurname = txtSurname.Text
        'If statement to check whether textboxes has any data in, if not it display a message to the user
        If strName = "" Then
            MessageBox.Show("Please enter your name")
            txtName.Focus()
            Exit Sub
        ElseIf strSurname = "" Then
            MsgBox("Please enter your surname")
            txtSurname.Focus()
            'Check whether the infromation is numeric, if it is it display the user a error message
        ElseIf IsNumeric(txtName.Text) = True Then
            MsgBox("Please enter a string")
            txtName.Clear()
            txtName.Focus()
        ElseIf IsNumeric(txtSurname.Text) = True Then
            MsgBox("Please enter a string")
            txtName.Clear()
            txtName.Focus()
        Else
            'If statement to check if the amount entered is equal or greater than the final amount so that the payment can go through
            If Amountdue >= decFinalAmount Then
          
                'Setting variable equal to final amount
                decAmount2Pay = decFinalAmount
                'Calculates the users change
                decChange = Amountdue - decFinalAmount
                'Displays how much the user has entered in to the textbox
                lstDisplayTotal.Items.Add("The amount paid is :" & "  " & Amountdue.ToString("C2"))
                'Display the users change in the listbox
                lstDisplayTotal.Items.Add("Your change is :" & vbTab & decChange.ToString("C2"))
                MsgBox("Thank you for your service")
                'Declaring variables to stor calculated amounts in so that it can be added to the database
                Dim strFinalAmount As String
                strFinalAmount = decFinalAmount
                Dim strDiscount As String
                strDiscount = decDiscountTotal

                'Inserts information into the sales information once the sale has been made
                query = "INSERT INTO Sales_Information (Custumer_Name , Customer_Surname , Products_Bought, Discount_Received, Total_Amount ) VALUES ('" + strName + "', '" + strSurname + "' , '" + strProductName & " " + "', '" + strDiscount + "', '" + strFinalAmount + "'   )"
                Try
                    'Opens connection
                    acc_Record.Open()
                    'This variable represents a Sql statement or stored procedure to execute against the datasource
                    Dim cmd As OleDbCommand
                    'It insures the the sql used gets stored and that the connection is open
                    'It executes the command
                    cmd = New OleDbCommand(query, acc_Record)
                    'Variable declared to read the data required from the database
                    Dim Reader As OleDbDataReader
                    'Executes reader
                    Reader = cmd.ExecuteReader
                    'It is used to represent the errors during run-time
                    'The message display where the problem might lay
                Catch ex As Exception
                    MsgBox(ex.Message)
                Finally
                    acc_Record.Close()
                End Try
            Else
                MsgBox("Please enter a valid Amount")
            End If
        End If
    End Sub


    Private Function CalcTotal(ByVal decSubt As Decimal, ByVal decDiscount As Decimal, ByVal VatAmount As Decimal) As Decimal
        'Calculates total amount
        Total = (decSubt - decDiscount) + VatAmount
        'Returns the total to be used where required
        Return Total
    End Function
    Private Function SalesTax(ByVal decSubT As Decimal, ByVal decDiscount As Decimal) As Decimal
        'Creating a constant in order to use in calculation
        Const VatPerc As Decimal = 0.15
        'Calculates the amount of VAT
        VatAmount = (decSubT - decDiscount) * VatPerc
        'Returns the VAT to be used where required
        Return VatAmount
    End Function

    Private Function DiscountAmount(ByVal decSubT As Decimal) As Decimal
        'Declaring a variable
        Dim decDiscountPerc As Decimal
        'If statement that checks first if its the index that has been selected
        'Then it assigns a Percentage to all the different items in that specific group
        If cboGroup.SelectedIndex = 2 Then
            If cboItem.SelectedIndex = 1 Then
                decDiscountPerc = 0.01
            ElseIf cboItem.SelectedIndex = 2 Then
                decDiscountPerc = 0.02
            ElseIf cboItem.SelectedIndex = 3 Then
                decDiscountPerc = 0.03
            ElseIf cboItem.SelectedIndex = 4 Then
                decDiscountPerc = 0.04
            ElseIf cboItem.SelectedIndex >= 5 Then
                decDiscountPerc = 0.05
            Else
                'If that group has not been selected, discount will be 0
                decDiscountPerc = 0
            End If

        End If
        'Calculates discount amount
        decDiscount = decSubT * decDiscountPerc
        'Returns discount to be used  where needed
        Return decDiscount
    End Function
    Private Sub cboGroup_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboGroup.SelectedIndexChanged
        'Clears combobox everytime it gets clicked on and also adds a blank space to the combobox to make it neater
        cboItem.Items.Clear()
        cboItem.Items.Add(" ")
        ' Variable declared to show a connection to the datasource
        Dim acc_Record As OleDbConnection
        acc_Record = New OleDbConnection
        'Type of access database application used
        acc_Record.ConnectionString = "Provider=Microsoft.ACE.OleDb.12.0;Data Source = " & DatabaseAddress
        'Checks for condition and if condition has been met and then selects all data from Product details group A
        If cboGroup.SelectedIndex = 1 Then
            query = "SELECT * FROM Product_Details_Group_A"

            Try
                'Opens connection 
                acc_Record.Open()
                'This variable represents a Sql statement or stored procedure to execute against the datasource
                Dim cmd As OleDbCommand
                'It insures the the sql used gets stored and that the connection is open
                'It executes the command
                cmd = New OleDbCommand(query, acc_Record)
                'Variable declared to read the data required from the database
                Dim Reader As OleDbDataReader
                'Executes reader
                Reader = cmd.ExecuteReader
                'Receives required information from database while the reader has been executed
                While Reader.Read
                    'Receives data of certain column in database
                    strProductName = Reader.GetString(0)
                    'Populates combobox with the data of the database
                    cboItem.Items.Add(strProductName)
                End While
                ' It is used to represent the errors during run-time
                'The message display where the problem might lay
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                acc_Record.Close()
            End Try
            'Checks for condition and if condition has been met and then selects all data from Product details group B
        ElseIf cboGroup.SelectedIndex = 2 Then
            query = "SELECT * FROM Product_Details_Group_B"
            Try
                'Opens connection 
                acc_Record.Open()
                'This variable represents a Sql statement or stored procedure to execute against the datasource
                Dim cmd As OleDbCommand
                'It insures the the sql used gets stored and that the connection is open
                'It executes the command
                cmd = New OleDbCommand(query, acc_Record)
                'Variable declared to read the data required from the database
                Dim Reader As OleDbDataReader
                'Executes reader
                Reader = cmd.ExecuteReader

                'Receives required information from database while the reader has been executed
                While Reader.Read
                    'Receives data of certain column in database
                    strProductName = Reader.GetString(0)
                    'Populates combobox with the data of the database
                    cboItem.Items.Add(strProductName)
                End While
                ' It is used to represent the errors during run-time
                'The message display where the problem might lay
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                acc_Record.Close()
            End Try
        End If


    End Sub
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click

        'If statement to check for certain index and then it does certain tasks according to selection
        If cboGroup.SelectedIndex = 1 Then
            ' Variable declared to show a connection to the datasource
            Dim acc_Record As OleDbConnection
            acc_Record = New OleDbConnection
            'Type of access database application used
            acc_Record.ConnectionString = "Provider=Microsoft.ACE.OleDb.12.0;Data Source = " & DatabaseAddress
            'Sql statement that selects all the information of the selected item in the combobox from the database table
            query = "SELECT * FROM Product_Details_Group_A WHERE Product_Name ='" + cboItem.SelectedItem + "'"

            Try
                'Opens connection
                acc_Record.Open()
                'This variable represents a Sql statement or stored procedure to execute against the datasource
                Dim cmd As OleDbCommand
                'It insures the the sql used gets stored and that the connection is open
                'It executes the command
                cmd = New OleDbCommand(query, acc_Record)
                Dim Reader As OleDbDataReader
                'Executes reader
                Reader = cmd.ExecuteReader
                'Receives required information from database while the reader has been executed
                While Reader.Read
                    'Receives different information from different columns in the database
                    strProductName = Reader.GetString(0)
                    ProductCode = Reader.GetString(1)
                    ProductPrice = Reader.GetDecimal(2)
                    ProductQty = Reader.GetInt32(3)
                    'Variable set equal to the products price
                    decAmount = ProductPrice
                    'Displays the item name and price that the user has selected
                    lstDisplayTotal.Items.Add(strProductName & vbTab & vbTab & vbTab & decAmount.ToString("C2"))
                End While
                ' It is used to represent the errors during run-time
                'The message display where the problem might lay
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                acc_Record.Close()
            End Try

        ElseIf cboGroup.SelectedIndex = 2 Then
            ' Variable declared to show a connection to the datasource
            Dim acc_Record As OleDbConnection
            acc_Record = New OleDbConnection
            'Type of access database application used
            acc_Record.ConnectionString = "Provider=Microsoft.ACE.OleDb.12.0;Data Source = " & DatabaseAddress
            'Sql statement that selects all the information of the selected item in the combobox from the database table
            query = "SELECT * FROM Product_Details_Group_B WHERE Product_Name ='" + cboItem.SelectedItem + "'"

            Try
                'Opens connection
                acc_Record.Open()
                'This variable represents a Sql statement or stored procedure to execute against the datasource
                Dim cmd As OleDbCommand
                'It insures the the sql used gets stored and that the connection is open
                'It executes the command
                cmd = New OleDbCommand(query, acc_Record)
                Dim Reader As OleDbDataReader
                'Executes reader
                Reader = cmd.ExecuteReader
                'Receives required information from database while the reader has been executed
                While Reader.Read
                    'Receives different information from different columns in the database
                    strProductName = Reader.GetString(0)
                    ProductCode = Reader.GetString(1)
                    ProductPrice = Reader.GetDecimal(2)
                    ProductQty = Reader.GetInt32(3)
                    'Variable set equal to the  products price
                    decAmount2 = ProductPrice
                    'Displays the item name and price that the user has selected
                    lstDisplayTotal.Items.Add(strProductName & vbTab & vbTab & vbTab & decAmount2.ToString("C2"))
                End While
                ' It is used to represent the errors during run-time
                'The message display where the problem might lay
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                acc_Record.Close()
            End Try
        End If
    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        'Setting variables equal to the information entered in the textboxes
        strName = txtName.Text
        strSurname = txtSurname.Text
        'If statement used to check if textbox is left empty, if it is it displays the user a message becuase the users details must be added to the record
        If strName = "" Then
            MessageBox.Show("Please enter your name")
            txtName.Focus()
            Exit Sub
        ElseIf strSurname = "" Then
            MsgBox("Please enter your surname")
            txtSurname.Focus()
            'Checks if it is numeric to minimize human-error and then displays a message box to instruct the user to enter the right type of data
        ElseIf IsNumeric(txtName.Text) = True Then
            MsgBox("Please enter a string")
            txtName.Clear()
            txtName.Focus()
        ElseIf IsNumeric(txtSurname.Text) = True Then
            MsgBox("Please enter a string")
            txtName.Clear()
            txtName.Focus()
        End If
        
        'Calculates sub-total
        decSubT = decAmount + decAmount2
        'Enables controls only after the calculation has been done
        btnPay.Enabled = True
        txtAmount.Enabled = True
        txtAmount.Focus()
        'Setting variables equals to the final answers calculated in the functions
        decDiscountTotal = DiscountAmount(decSubT)
        decVatTotal = SalesTax(decSubT, decDiscount)
        decFinalAmount = CalcTotal(decSubT, decDiscount, VatAmount)
        'Displays an appropriate label for the user in the listbox aswell as the amount calculated
        lstDisplayTotal.Items.Add(" ")
        lstDisplayTotal.Items.Add("Name & Surname :" & vbTab & strName & vbTab & strSurname)
        lstDisplayTotal.Items.Add("_________________________________________________________________________________")
        lstDisplayTotal.Items.Add("Sub-Total" & vbNewLine & vbTab & decSubT.ToString("C2"))
        lstDisplayTotal.Items.Add("Discount" & vbNewLine & vbTab & vbTab & decDiscountTotal.ToString("C2"))
        lstDisplayTotal.Items.Add("VAT Amount :" & vbNewLine & vbTab & decVatTotal.ToString("C2"))
        lstDisplayTotal.Items.Add("The total is : " & vbNewLine & vbTab & decFinalAmount.ToString("C2"))
    End Sub

    Private Sub Point_of_Sales_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Creates a heading in the form
        lstDisplayTotal.Items.Add("Item Selection : ")
        lstDisplayTotal.Items.Add("_________________________________________________________________________________")
        'Disables controls to minimize possible human error
        btnPay.Enabled = False
        txtAmount.Enabled = False
    End Sub


    Private Sub ClearControls()
        'Clears controls and sets focus to the name
        txtName.Clear()
        txtSurname.Clear()
        txtAmount.Clear()
        lstDisplayTotal.Items.Clear()
        cboGroup.SelectedIndex = 0
        cboItem.SelectedIndex = 0
        txtName.Focus()
    End Sub
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'Calls up Sub created to clear controls
        ClearControls()
    End Sub
End Class