﻿'Nathan Absolom (09)
'2017041486
Imports System.Data.OleDb
Imports System.IO

Public Class View_Sales_Information
    'Variable created to search for database file in the debug form
    Public DatabaseAddress As String = Directory.GetCurrentDirectory() & "\ISAT.accdb"
    'Declaring a variable to use for sql statements
    Public query As String
    'Variables created to store calculated variables in
    Dim strTransaction As Integer
    Dim strCustName As String
    Dim strCustSurname As String
    Dim TotalAmount As String
    Dim DiscountReceived As String
    Dim ProductsBought As String

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        'Hides current form
        Me.Hide()
        'Shows main menu form
        Main_Menu.Show()
    End Sub
  
    Private Sub View_Sales_Information_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Hides controls
        cboTransactionNum.Hide()
        Label1.Hide()
    End Sub

    Private Sub btnViewSale_Click(sender As Object, e As EventArgs) Handles btnViewSale.Click
        'Clears listbox
        lstDisplay.Items.Clear()
        'Search for certain conditions then executes the instructions there after
        If ComboBox1.SelectedIndex = 1 Then
            'Selects all the items from sales information table
            query = "SELECT * FROM Sales_Information"
            ' Variable declared to show a connection to the datasource
            Dim acc_Record As OleDbConnection
            acc_Record = New OleDbConnection
            'Type of access database application used  
            acc_Record.ConnectionString = "Provider=Microsoft.ACE.OleDb.12.0;Data Source = " & DatabaseAddress
            'Selects all from the certain record in the table which is equal to the transaction number
            query = "SELECT * FROM Sales_Information WHERE Cint(Transaction_Number)='" + cboTransactionNum.Text + "'"
            Try
                'Opens connection
                acc_Record.Open()
                'This variable represents a Sql statement or stored procedure to execute against the datasource
                Dim cmd As OleDbCommand
                'It insures the the sql used gets stored and that the connection is open
                'It executes the command
                cmd = New OleDbCommand(query, acc_Record)
                'Variable declared to read the data required from the database
                Dim Reader As OleDbDataReader
                'Executes reader 
                Reader = cmd.ExecuteReader
                'Labels added for display purposes
                lstDisplay.Items.Add("Customer name & Surname " & vbTab & "Total Amount" & vbTab & "Discount Received" & vbTab & "Products Bought")
                While Reader.Read
                    'Receives data from database
                    strCustName = Reader.GetString(0)
                    strCustSurname = Reader.GetString(1)
                    TotalAmount = Reader.GetString(2)
                    DiscountReceived = Reader.GetString(3)
                    ProductsBought = Reader.GetString(4)
                    strTransaction = Reader.GetInt32(5)
                    'Adds items under suitable headings
                    lstDisplay.Items.Add(strCustName & vbTab & strCustSurname & vbTab & vbTab & TotalAmount & vbTab & vbTab & DiscountReceived & ProductsBought)
                End While
                ' It is used to represent the errors during run-time
                'The message display where the problem might lay
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                acc_Record.Close()
            End Try
        End If
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        Dim acc_Record As OleDbConnection
        acc_Record = New OleDbConnection
        'Type of access database application used
        acc_Record.ConnectionString = "Provider=Microsoft.ACE.OleDb.12.0;Data Source = " & DatabaseAddress
        'Checks for condition and if condition has been met and then selects all data from Product details group A
        If ComboBox1.SelectedIndex = 1 Then
            query = "SELECT * FROM Sales_Information"
            Label1.Show()
            cboTransactionNum.Show()
            Try
                'Opens connection 
                acc_Record.Open()
                'This variable represents a Sql statement or stored procedure to execute against the datasource
                Dim cmd As OleDbCommand
                'It insures the the sql used gets stored and that the connection is open
                'It executes the command
                cmd = New OleDbCommand(query, acc_Record)
                'Variable declared to read the data required from the database
                Dim Reader As OleDbDataReader
                'Executes reader
                Reader = cmd.ExecuteReader
                'Receives required information from database while the reader has been executed
                While Reader.Read
                    'Receives data of certain column in database
                    strTransaction = Reader.GetInt32(5)
                    'Populates combobox with the data of the database
                    cboTransactionNum.Items.Add(strTransaction)
                End While
                ' It is used to represent the errors during run-time
                'The message display where the problem might lay
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                acc_Record.Close()
            End Try
        End If
    End Sub
End Class