﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Main_Menu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Main_Menu))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnViewSales = New System.Windows.Forms.Button()
        Me.btnProdInfo = New System.Windows.Forms.Button()
        Me.btnPOS = New System.Windows.Forms.Button()
        Me.btnProdQuan = New System.Windows.Forms.Button()
        Me.btnProdDetails = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(94, 17)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(213, 77)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 13
        Me.PictureBox1.TabStop = False
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(94, 383)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(213, 47)
        Me.btnExit.TabIndex = 12
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnViewSales
        '
        Me.btnViewSales.Location = New System.Drawing.Point(94, 324)
        Me.btnViewSales.Name = "btnViewSales"
        Me.btnViewSales.Size = New System.Drawing.Size(213, 53)
        Me.btnViewSales.TabIndex = 11
        Me.btnViewSales.Text = "View Product Sales Information"
        Me.btnViewSales.UseVisualStyleBackColor = True
        '
        'btnProdInfo
        '
        Me.btnProdInfo.Location = New System.Drawing.Point(94, 269)
        Me.btnProdInfo.Name = "btnProdInfo"
        Me.btnProdInfo.Size = New System.Drawing.Size(213, 49)
        Me.btnProdInfo.TabIndex = 10
        Me.btnProdInfo.Text = "View Product Information"
        Me.btnProdInfo.UseVisualStyleBackColor = True
        '
        'btnPOS
        '
        Me.btnPOS.Location = New System.Drawing.Point(94, 212)
        Me.btnPOS.Name = "btnPOS"
        Me.btnPOS.Size = New System.Drawing.Size(213, 51)
        Me.btnPOS.TabIndex = 9
        Me.btnPOS.Text = "Point of Sale"
        Me.btnPOS.UseVisualStyleBackColor = True
        '
        'btnProdQuan
        '
        Me.btnProdQuan.Location = New System.Drawing.Point(94, 159)
        Me.btnProdQuan.Name = "btnProdQuan"
        Me.btnProdQuan.Size = New System.Drawing.Size(213, 47)
        Me.btnProdQuan.TabIndex = 8
        Me.btnProdQuan.Text = "Update Product Quantity"
        Me.btnProdQuan.UseVisualStyleBackColor = True
        '
        'btnProdDetails
        '
        Me.btnProdDetails.Location = New System.Drawing.Point(94, 100)
        Me.btnProdDetails.Name = "btnProdDetails"
        Me.btnProdDetails.Size = New System.Drawing.Size(213, 53)
        Me.btnProdDetails.TabIndex = 7
        Me.btnProdDetails.Text = "Product Details"
        Me.btnProdDetails.UseVisualStyleBackColor = True
        '
        'Main_Menu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(336, 447)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnViewSales)
        Me.Controls.Add(Me.btnProdInfo)
        Me.Controls.Add(Me.btnPOS)
        Me.Controls.Add(Me.btnProdQuan)
        Me.Controls.Add(Me.btnProdDetails)
        Me.Name = "Main_Menu"
        Me.Text = "Main_Menu"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btnExit As Button
    Friend WithEvents btnViewSales As Button
    Friend WithEvents btnProdInfo As Button
    Friend WithEvents btnPOS As Button
    Friend WithEvents btnProdQuan As Button
    Friend WithEvents btnProdDetails As Button
End Class
