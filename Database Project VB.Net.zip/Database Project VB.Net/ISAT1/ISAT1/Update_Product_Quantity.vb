﻿'Nathan Absolom (09)
'2017041486
Imports System.Data.OleDb
Imports System.IO

Public Class Update_Product_Quantity
    'Declaring a variable to use for sql statements
    Dim query As String
    'Variable created to search for database file in the debug form
    Public DatabaseAddress As String = Directory.GetCurrentDirectory() & "\ISAT.accdb"


    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        'Hides current form
        Me.Hide()
        'Display main menu
        Main_Menu.Show()
    End Sub

    Private Sub btnAcceptRecord_Click(sender As Object, e As EventArgs) Handles btnAcceptRecord.Click
        ' Variable declared to show a connection to the datasource
        Dim acc_Record As OleDbConnection
        acc_Record = New OleDbConnection
        'Type of access database application used    
        acc_Record.ConnectionString = "Provider=Microsoft.ACE.OleDb.12.0;Data Source = " & DatabaseAddress
        'This variable represents a Sql statement or stored procedure to execute against the datasource
        Dim cmd As OleDbCommand
        'Variable declared to read the data required from the database
        Dim Reader As OleDbDataReader
        'Checks for certain conditions
        If cboProdGroup.SelectedIndex = 1 Then
            'Selects all the products from Group A
            query = "SELECT * FROM Product_Details_Group_A"
            Try
                'Opens Connection
                acc_Record.Open()
                'Updates the quantity of the selected item
                query = "update Product_Details_Group_A set Product_Quantity = '" + txtQtyUpdate.Text + "'  where Product_Name='" + cboProdName.SelectedItem + "'"
                'It insures the the sql used gets stored and that the connection is open
                'It executes the command
                cmd = New OleDbCommand(query, acc_Record)
                'Executes reader
                Reader = cmd.ExecuteReader
                'Displays user a message to say that the data is saved
                MsgBox("Data Saved")
                'Closes connection
                acc_Record.Close()
                ' It is used to represent the errors during run-time
                'The message display where the problem might lay
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                acc_Record.Close()
            End Try

        ElseIf cboProdGroup.SelectedIndex = 2 Then
            'Selects all the products from Group B
            query = "SELECT * FROM Product_Details_Group_B"
            Try
                'Opens connection
                acc_Record.Open()
                'Updates the quantity of the selected item
                query = "update Product_Details_Group_B set Product_Quantity = '" + txtQtyUpdate.Text + "'  where Product_Name='" + cboProdName.SelectedItem + "'"
                'It insures the the sql used gets stored and that the connection is open
                'It executes the command
                cmd = New OleDbCommand(query, acc_Record)
                'Executes reader
                Reader = cmd.ExecuteReader
                'Displays user a message to say that the data is saved
                MsgBox("Data Saved")
                'Closes connection
                acc_Record.Close()
                ' It is used to represent the errors during run-time
                'The message display where the problem might lay
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                acc_Record.Close()
            End Try

        End If
    End Sub





    Private Sub cboProdGroup_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboProdGroup.SelectedIndexChanged
        'Clears combobox and adds a blankspace
        cboProdName.Items.Clear()
        cboProdName.Items.Add(" ")
        'Declaring a variable to be used to receive data from the database
        Dim strProductName As String
        ' Variable declared to show a connection to the datasource
        Dim acc_Record As OleDbConnection
        acc_Record = New OleDbConnection
        'Type of access database application used  
        acc_Record.ConnectionString = "Provider=Microsoft.ACE.OleDb.12.0;Data Source = " & DatabaseAddress
        'Checks for cerain condition first and then execute instruction
        If cboProdGroup.SelectedIndex = 1 Then
            'Selects all informatin of products in group A
            query = "SELECT * FROM Product_Details_Group_A"

            Try
                'Opens connection
                acc_Record.Open()
                'This variable represents a Sql statement or stored procedure to execute against the datasource
                Dim cmd As OleDbCommand
                'It insures the the sql used gets stored and that the connection is open
                'It executes the command
                cmd = New OleDbCommand(query, acc_Record)
                'Variable declared to read the data required from the database
                Dim Reader As OleDbDataReader
                'Executes reader
                Reader = cmd.ExecuteReader
                'While reader is executed it does certain instructions
                While Reader.Read
                    'Receives product names from database
                    strProductName = Reader.GetString(0)
                    'Adds the product names to the combobox
                    cboProdName.Items.Add(strProductName)

                End While
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try

        ElseIf cboProdGroup.SelectedIndex = 2 Then
            'Selects all informatin of products in group A
            query = "SELECT * FROM Product_Details_Group_B"

            Try
                'Opens connection
                acc_Record.Open()
                'This variable represents a Sql statement or stored procedure to execute against the datasource
                Dim cmd As OleDbCommand
                'It insures the the sql used gets stored and that the connection is open
                'It executes the command
                cmd = New OleDbCommand(query, acc_Record)
                'Variable declared to read the data required from the database
                Dim Reader As OleDbDataReader
                'Executes reader
                Reader = cmd.ExecuteReader
                'While reader is executed it does certain instructions
                While Reader.Read
                    'Receives product names from database
                    strProductName = Reader.GetString(0)
                    'Adds the product names to the combobox
                    cboProdName.Items.Add(strProductName)

                End While
                ' It is used to represent the errors during run-time
                'The message display where the problem might lay
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If
    End Sub


End Class