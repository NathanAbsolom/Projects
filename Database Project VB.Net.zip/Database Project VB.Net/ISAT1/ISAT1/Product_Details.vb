﻿'Nathan Absolom (09)
'2017041486
Imports System.Data.OleDb
Imports System.IO

Public Class Product_Details
    'Variable created to search for database file in the debug form
    Public DatabaseAddress As String = Directory.GetCurrentDirectory() & "\ISAT.accdb"
    'Declaring a variable to use for sql statements
    Public query As String
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        'Hides current form
        Me.Hide()
        'Show main menu interface
        Main_Menu.Show()
    End Sub

    Private Sub Product_Details_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cboGroup.Items.Add("")
        cboGroup.Items.Add("Group A")
        cboGroup.Items.Add("Group B")
    End Sub

    Private Sub btnCapture_Click(sender As Object, e As EventArgs) Handles btnCapture.Click

        'Checks whether user enters the correct type of data or whether it is left open, if it is it does not allow the user to proceed with adding a item
        If txtProdName.Text = "" Then
            MsgBox("Please enter new product name")
            txtProdName.Focus()
            Exit Sub
        End If
        If txtProdCode.Text = "" Then
            MsgBox("Please enter new product code")
            txtProdCode.Focus()
            Exit Sub
        End If
        'Checks if data is numeric
        If IsNumeric(txtProdPrice.Text) = False Then
            MsgBox("Please enter integer")
            txtProdPrice.Clear()
            txtProdPrice.Focus()
            Exit Sub

        End If
        If IsNumeric(txtProdQty.Text) = False Then
            MsgBox("Please enter integer")
            txtProdQty.Clear()
            txtProdQty.Focus()
            Exit Sub
        End If
        'Checks if the textboxes is empty or not
        If txtProdPrice.Text = "" Then
            MsgBox("Please enter new product price")
            txtProdPrice.Focus()
            Exit Sub
        End If
        If txtProdQty.Text = "" Then
            MsgBox("Please enter new product quantity")
            txtProdQty.Focus()
            Exit Sub
        Else
            ' Variable declared to show a connection to the datasource
            Dim acc_Record As OleDbConnection
            acc_Record = New OleDbConnection
            'Type of access database application used
            acc_Record.ConnectionString = "Provider=Microsoft.ACE.OleDb.12.0;Data Source = " & DatabaseAddress
            'First checks what index has been selected
            'Then adds information into database table by receiving the value from the textboxes
            If cboGroup.SelectedIndex = 1 Then
                query = "INSERT INTO Product_Details_Group_A (Product_Name , Product_Code, Product_Quantity , Product_Price) VALUES ('" + txtProdName.Text + "', '" + txtProdCode.Text + "' ,'" + txtProdQty.Text + "','" + txtProdPrice.Text + "' )"

                Try
                    'Opens connection 
                    acc_Record.Open()
                    'This variable represents a Sql statement or stored procedure to execute against the datasource
                    Dim cmd As OleDbCommand
                    'It insures the the sql used gets stored and that the connection is open
                    'It executes the command
                    cmd = New OleDbCommand(query, acc_Record)
                    'Variable declared to read the data required from the database
                    Dim Reader As OleDbDataReader
                    'Executes reader
                    Reader = cmd.ExecuteReader
                    ' It is used to represent the errors during run-time
                    'The message display where the problem might lay
                Catch ex As Exception
                    MsgBox(ex.Message)
                Finally
                    acc_Record.Close()
                End Try
                'Displays the user a message
                MsgBox("Product Successfully added to Group A")

            ElseIf cboGroup.SelectedIndex = 2 Then
                query = "INSERT INTO Product_Details_Group_B (Product_Name , Product_Code, Product_Quantity , Product_Price) VALUES ('" + txtProdName.Text + "', '" + txtProdCode.Text + "' ,'" + txtProdQty.Text + "','" + txtProdPrice.Text + "' )"

                Try
                    'Opens connection
                    acc_Record.Open()
                    'This variable represents a Sql statement or stored procedure to execute against the datasource
                    Dim cmd As OleDbCommand
                    'It insures the the sql used gets stored and that the connection is open
                    'It executes the command
                    cmd = New OleDbCommand(query, acc_Record)
                    Dim Reader As OleDbDataReader
                    'Executes reader
                    Reader = cmd.ExecuteReader
                    ' It is used to represent the errors during run-time
                    'The message display where the problem might lay
                Catch ex As Exception
                    MsgBox(ex.Message)
                Finally
                    acc_Record.Close()
                End Try
                'Displays the user a message
                MsgBox("Product Successfully added to Group B")

            Else
                'If the user did not select a group the user wont be able to add a new product
                MsgBox("Please select a group where you want to add the new item in")
                cboGroup.Focus()
                Exit Sub
            End If
        End If

    End Sub
End Class