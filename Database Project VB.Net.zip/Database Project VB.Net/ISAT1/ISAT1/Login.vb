﻿'Nathan Absolom (09)
'2017041486
Imports System.Data.OleDb
Imports System.IO
Public Class Login
    'Variable created to search for database file in the debug form
    Public DatabaseAddress As String = Directory.GetCurrentDirectory() & "\ISAT.accdb"

    'Variable declared to use for queries
    Dim query As String


    Private Sub Login_Or_SignUp_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Changes the text of password textbox to bullets
        txtPassword.UseSystemPasswordChar = True
    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        'If statements to check whether the textboxes is empty or not
        If txtUsername.Text = "" Then
            MsgBox("Please enter username")
            txtUsername.Focus()
            Exit Sub
        End If

        If txtPassword.Text = "" Then
            MsgBox("Please enter password")
            txtPassword.Focus()
            Exit Sub
        End If
        Dim RootOledbConn As New OleDbConnection
        Try
            ' Variable declared to show a connection to the datasource

            RootOledbConn = New OleDbConnection
            'Type of access database application used
            RootOledbConn.ConnectionString = " Provider=microsoft.ACE.OLEDB.12.0;Data Source = " & DatabaseAddress
            'variable that represents a set of data and also to fill the dataset and update datasource
            Dim MyDataAdapter As New OleDbDataAdapter
            'Variable that holds the memory cache of the data
            Dim ds As DataSet = New DataSet
            'Opens connection from the application to the database appliction created
            RootOledbConn.Open()

            'Query used to search in the database tables whether the textboxes values are equal to that of in the database so that login can be successfull
            Dim query As String = "SELECT * from  Login WHERE Username = '" + Me.txtUsername.Text + "' AND Password = '" + Me.txtPassword.Text + "'"

            'This variable represents a Sql statement or stored procedure to execute against the datasource
            Dim command As OleDbCommand
            'It insures the the sql used gets stored and that the connection is open
            'It executes the command
            command = New OleDbCommand(query, RootOledbConn)
            MyDataAdapter.SelectCommand = command
            MyDataAdapter.Fill(ds)

            'Variable declared as datatable so that it can get the necessary information from the table to be used
            Dim myTable As New System.Data.DataTable
            myTable = ds.Tables(0)

            'If statement to check whether the information in the textbox is equeal to that tables information in order to log in
            If myTable.Rows.Count <> 0 Then
                MsgBox("Successfully Loggen In !")
                Me.Hide()
                Main_Menu.Show()
            Else
                'If the information is enter incorrectly it displays the user a message to show that user don't exist
                MsgBox("There is not such user,please try again")
                Me.txtUsername.Clear()
                Me.txtPassword.Clear()
                txtUsername.Focus()
                Exit Sub
            End If
            'It is used to represent the errors during run-time
            'The message display where the problem might lay
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            RootOledbConn.Close()
        End Try

    End Sub

    Private Sub chkShowPass_CheckedChanged(sender As Object, e As EventArgs) Handles chkShowPass.CheckedChanged
        'Chekcs whether the checkbox has been ticked so that it can display the text in the textbox in normal text
        If chkShowPass.Checked = True Then
            txtPassword.UseSystemPasswordChar = False
        End If
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        MsgBox("Are you sure you want to exit ?", vbYesNo)

        If MsgBoxResult.Yes Then
            Me.Close()
        Else
            Me.Show()
        End If
    End Sub
End Class
