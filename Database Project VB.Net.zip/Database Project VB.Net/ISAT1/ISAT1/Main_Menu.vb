﻿'Nathan Absolom (09)
'2017041486
Public Class Main_Menu
    Private Sub btnProdDetails_Click(sender As Object, e As EventArgs) Handles btnProdDetails.Click
        'Close current form
        Me.Hide()
        'Shows product details form
        Product_Details.Show()

    End Sub

    Private Sub btnProdQuan_Click(sender As Object, e As EventArgs) Handles btnProdQuan.Click
        'Close current form
        Me.Hide()
        'Show product quantity form
        Update_Product_Quantity.Show()
    End Sub


    Private Sub btnPOS_Click(sender As Object, e As EventArgs) Handles btnPOS.Click
        'Close current form
        Me.Hide()
        'Show point of sales form
        Point_of_Sales.Show()

    End Sub

    Private Sub btnProdInfo_Click(sender As Object, e As EventArgs) Handles btnProdInfo.Click
        'Close current form
        Me.Hide()
        'Show view product information form
        View_Product_Information.Show()

    End Sub

    Private Sub btnViewSales_Click(sender As Object, e As EventArgs) Handles btnViewSales.Click
        'Close current form
        Me.Hide()
        'Show view sales information form
        View_Sales_Information.Show()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'Closes application
        Application.Exit()
    End Sub
End Class