﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class View_Product_Information
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cboGroups = New System.Windows.Forms.ComboBox()
        Me.btnViewProduct = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnViewAllProducts = New System.Windows.Forms.Button()
        Me.cboItems = New System.Windows.Forms.ComboBox()
        Me.lstOUTPUT = New System.Windows.Forms.ListBox()
        Me.CheckedListBox1 = New System.Windows.Forms.CheckedListBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'cboGroups
        '
        Me.cboGroups.FormattingEnabled = True
        Me.cboGroups.Location = New System.Drawing.Point(549, 113)
        Me.cboGroups.Name = "cboGroups"
        Me.cboGroups.Size = New System.Drawing.Size(157, 21)
        Me.cboGroups.TabIndex = 12
        '
        'btnViewProduct
        '
        Me.btnViewProduct.Location = New System.Drawing.Point(483, 256)
        Me.btnViewProduct.Name = "btnViewProduct"
        Me.btnViewProduct.Size = New System.Drawing.Size(184, 36)
        Me.btnViewProduct.TabIndex = 11
        Me.btnViewProduct.Text = "View Product"
        Me.btnViewProduct.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(109, 383)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(137, 63)
        Me.btnCancel.TabIndex = 8
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnViewAllProducts
        '
        Me.btnViewAllProducts.Location = New System.Drawing.Point(483, 154)
        Me.btnViewAllProducts.Name = "btnViewAllProducts"
        Me.btnViewAllProducts.Size = New System.Drawing.Size(184, 31)
        Me.btnViewAllProducts.TabIndex = 7
        Me.btnViewAllProducts.Text = "View All Products"
        Me.btnViewAllProducts.UseVisualStyleBackColor = True
        '
        'cboItems
        '
        Me.cboItems.FormattingEnabled = True
        Me.cboItems.Location = New System.Drawing.Point(549, 200)
        Me.cboItems.Name = "cboItems"
        Me.cboItems.Size = New System.Drawing.Size(157, 21)
        Me.cboItems.TabIndex = 17
        '
        'lstOUTPUT
        '
        Me.lstOUTPUT.FormattingEnabled = True
        Me.lstOUTPUT.Location = New System.Drawing.Point(29, 39)
        Me.lstOUTPUT.Name = "lstOUTPUT"
        Me.lstOUTPUT.Size = New System.Drawing.Size(393, 316)
        Me.lstOUTPUT.TabIndex = 19
        '
        'CheckedListBox1
        '
        Me.CheckedListBox1.FormattingEnabled = True
        Me.CheckedListBox1.Location = New System.Drawing.Point(1305, 235)
        Me.CheckedListBox1.Name = "CheckedListBox1"
        Me.CheckedListBox1.Size = New System.Drawing.Size(120, 94)
        Me.CheckedListBox1.TabIndex = 20
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(428, 113)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(115, 13)
        Me.Label1.TabIndex = 21
        Me.Label1.Text = "Please select a group :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(428, 208)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(107, 13)
        Me.Label2.TabIndex = 22
        Me.Label2.Text = "Please select a item :"
        '
        'View_Product_Information
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(718, 457)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.CheckedListBox1)
        Me.Controls.Add(Me.lstOUTPUT)
        Me.Controls.Add(Me.cboItems)
        Me.Controls.Add(Me.cboGroups)
        Me.Controls.Add(Me.btnViewProduct)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnViewAllProducts)
        Me.Name = "View_Product_Information"
        Me.Text = "View_Product_Information"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents cboGroups As ComboBox
    Friend WithEvents btnViewProduct As Button
    Friend WithEvents btnCancel As Button
    Friend WithEvents btnViewAllProducts As Button
    Friend WithEvents cboItems As System.Windows.Forms.ComboBox
    Friend WithEvents lstOUTPUT As ListBox
    Friend WithEvents CheckedListBox1 As CheckedListBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
End Class
