﻿'Nathan Absolom (09)
'2017041486
Imports System.Data.OleDb
Imports System.IO

Public Class View_Product_Information
    'Variable created to search for database file in the debug form
    Public DatabaseAddress As String = Directory.GetCurrentDirectory() & "\ISAT.accdb"
    'variable created for sql statements
    Dim query As String
    'Variables created to be used to received data from database table
    Dim strProductName As String
    Dim ProductCode As String
    Dim ProductQty As Integer
    Dim ProductPrice As Decimal

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        'Hides current form
        Me.Hide()
        'Shows main menu
        Main_Menu.Show()
    End Sub

    Private Sub btnViewAllProducts_Click(sender As Object, e As EventArgs) Handles btnViewAllProducts.Click
        'Clears listbox
        lstOUTPUT.Items.Clear()
        'Checks for certain conditions then executes the task
        If cboGroups.SelectedIndex = 1 Then
            ' Variable declared to show a connection to the datasource
            Dim acc_Record As OleDbConnection
            acc_Record = New OleDbConnection
            'Type of access database application used    
            acc_Record.ConnectionString = "Provider=Microsoft.ACE.OleDb.12.0;Data Source = " & DatabaseAddress
            'Selects all the data from database table
            query = "SELECT * FROM Product_Details_Group_A "
            Try
                'Opens connection
                acc_Record.Open()
                'This variable represents a Sql statement or stored procedure to execute against the datasource
                Dim cmd As OleDbCommand
                'It insures the the sql used gets stored and that the connection is open
                'It executes the command
                cmd = New OleDbCommand(query, acc_Record)
                'Variable declared to read the data required from the database
                Dim Reader As OleDbDataReader
                'Executes reader
                Reader = cmd.ExecuteReader
                'Adds labels to make display neat
                lstOUTPUT.Items.Add("Product Name " & vbTab & "Product Code" & vbTab & "Product Price" & vbTab & "Product Quantity")
                'While the reader is running it receives ceratin data from the database table
                While Reader.Read
                    strProductName = Reader.GetString(0)
                    ProductCode = Reader.GetString(1)
                    ProductPrice = Reader.GetDecimal(2)
                    ProductQty = Reader.GetInt32(3)
                    'Adds products to the listbox under its respective labels
                    lstOUTPUT.Items.Add(strProductName & vbTab & ProductCode & vbTab & vbTab & ProductPrice.ToString("C") & vbTab & vbTab & ProductQty)
                End While
                ' It is used to represent the errors during run-time
                'The message display where the problem might lay
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try


        ElseIf cboGroups.SelectedIndex = 2 Then
            ' Variable declared to show a connection to the datasource
            Dim acc_Record As OleDbConnection
            acc_Record = New OleDbConnection
            'Type of access database application used 
            acc_Record.ConnectionString = "Provider=Microsoft.ACE.OleDb.12.0;Data Source = " & DatabaseAddress
            'Selects all the data from database table

            query = "SELECT * FROM Product_Details_Group_B "
            Try
                'Opens connection
                acc_Record.Open()
                'This variable represents a Sql statement or stored procedure to execute against the datasource
                Dim cmd As OleDbCommand
                'It insures the the sql used gets stored and that the connection is open
                'It executes the command
                cmd = New OleDbCommand(query, acc_Record)
                'Variable declared to read the data required from the database
                Dim Reader As OleDbDataReader
                'Executes reader
                Reader = cmd.ExecuteReader
                'Adds labels to make display neat
                lstOUTPUT.Items.Add("Product Name " & vbTab & "Product Code" & vbTab & "Product Price" & vbTab & "Product Quantity")
                'While the reader is running it receives ceratin data from the database table
                While Reader.Read
                    strProductName = Reader.GetString(0)
                    ProductCode = Reader.GetString(1)
                    ProductPrice = Reader.GetDecimal(2)
                    ProductQty = Reader.GetInt32(3)
                    'Adds products to the listbox under its respective labels
                    lstOUTPUT.Items.Add(strProductName & vbTab & ProductCode & vbTab & vbTab & ProductPrice.ToString("C") & vbTab & vbTab & ProductQty)
                End While
                ' It is used to represent the errors during run-time
                'The message display where the problem might lay
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try

        Else
            'Displays a message to the user and sets focus to the group combobox
            MsgBox("Please select a group you wish to view items from")
            cboGroups.Focus()
            Exit Sub
        End If
    End Sub
    Private Sub View_Product_Information_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cboGroups.Items.Add("")
        cboGroups.Items.Add("Group A")
        cboGroups.Items.Add("Group B")

    End Sub

    Private Sub btnViewProduct_Click(sender As Object, e As EventArgs) Handles btnViewProduct.Click
        'Clears listbox
        lstOUTPUT.Items.Clear()
        'Checks for certain condition
        If cboGroups.SelectedIndex = 1 Then

            ' Variable declared to show a connection to the datasource
            Dim acc_Record As OleDbConnection
            acc_Record = New OleDbConnection
            'Type of access database application used  
            acc_Record.ConnectionString = "Provider=Microsoft.ACE.OleDb.12.0;Data Source = " & DatabaseAddress
            'Selects all information from the database which is equal to the name of the selected item
            query = "SELECT * FROM Product_Details_Group_A WHERE Product_Name ='" + cboItems.SelectedItem + "'"

            Try
                'Opens connection
                acc_Record.Open()
                'This variable represents a Sql statement or stored procedure to execute against the datasource
                Dim cmd As OleDbCommand
                'It insures the the sql used gets stored and that the connection is open
                'It executes the command
                cmd = New OleDbCommand(query, acc_Record)
                'Variable declared to read the data required from the database
                Dim Reader As OleDbDataReader
                'Executes reader
                Reader = cmd.ExecuteReader
                'Adds labels to make display neat
                lstOUTPUT.Items.Add("Product Name " & vbTab & "Product Code" & vbTab & "Product Price" & vbTab & "Product Quantity")
                'While the reader is running it receives ceratin data from the database table
                While Reader.Read
                    strProductName = Reader.GetString(0)
                    ProductCode = Reader.GetString(1)
                    ProductPrice = Reader.GetDecimal(2)
                    ProductQty = Reader.GetInt32(3)
                    'Adds products to the listbox under its respective labels
                    lstOUTPUT.Items.Add(strProductName & vbTab & ProductCode & vbTab & vbTab & ProductPrice.ToString("C") & vbTab & vbTab & ProductQty)
                End While
                ' It is used to represent the errors during run-time
                'The message display where the problem might lay
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try


        ElseIf cboGroups.SelectedIndex = 2 Then
            ' Variable declared to show a connection to the datasource
            Dim acc_Record As OleDbConnection
            acc_Record = New OleDbConnection
            'Type of access database application used  
            acc_Record.ConnectionString = "Provider=Microsoft.ACE.OleDb.12.0;Data Source = " & DatabaseAddress
            'Selects all information from the database which is equal to the name of the selected item
            query = "SELECT * FROM Product_Details_Group_B WHERE Product_Name ='" + cboItems.SelectedItem + "'"

            Try
                'Opens connection
                acc_Record.Open()
                'This variable represents a Sql statement or stored procedure to execute against the datasource
                Dim cmd As OleDbCommand
                'It insures the the sql used gets stored and that the connection is open
                'It executes the command
                cmd = New OleDbCommand(query, acc_Record)
                'Variable declared to read the data required from the database
                Dim Reader As OleDbDataReader
                'Executes reader
                Reader = cmd.ExecuteReader
                'Adds products to the listbox under its respective labels
                lstOUTPUT.Items.Add("Product Name " & vbTab & "Product Code" & vbTab & "Product Price" & vbTab & "Product Quantity")
                'While the reader is running it receives ceratin data from the database table
                While Reader.Read
                    strProductName = Reader.GetString(0)
                    ProductCode = Reader.GetString(1)
                    ProductPrice = Reader.GetDecimal(2)
                    ProductQty = Reader.GetInt32(3)
                    'Adds products to the listbox under its respective labels
                    lstOUTPUT.Items.Add(strProductName & vbTab & ProductCode & vbTab & vbTab & ProductPrice.ToString("C") & vbTab & vbTab & ProductQty)
                End While
                ' It is used to represent the errors during run-time
                'The message display where the problem might lay
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try

        Else
            'Display the user a message and sets focus to combobox
            MsgBox("Please select a group you wish to view items from")
            cboGroups.Focus()
            Exit Sub
        End If

    End Sub

    Private Sub cboGroups_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboGroups.SelectedIndexChanged
        'Clears combox and adds a blankspace
        cboItems.Items.Clear()
        cboItems.Items.Add(" ")
        ' Variable declared to show a connection to the datasource
        Dim acc_Record As OleDbConnection
        acc_Record = New OleDbConnection
        'Type of access database application used  
        acc_Record.ConnectionString = "Provider=Microsoft.ACE.OleDb.12.0;Data Source = " & DatabaseAddress
        'Chekcs for certain condition and then executes the instruction if certain conditions are met
        If cboGroups.SelectedIndex = 1 Then
            'Selects all the product information from group A
            query = "SELECT * FROM Product_Details_Group_A"
            Try
                'Opens connection
                acc_Record.Open()
                'This variable represents a Sql statement or stored procedure to execute against the datasource
                Dim cmd As OleDbCommand
                'It insures the the sql used gets stored and that the connection is open
                'It executes the command
                cmd = New OleDbCommand(query, acc_Record)
                'Variable declared to read the data required from the database
                Dim Reader As OleDbDataReader
                'Executes reader 
                Reader = cmd.ExecuteReader
                'While the reader is running it receives ceratin data from the database table
                While Reader.Read
                    strProductName = Reader.GetString(0)
                    'Adds item names to the combobox
                    cboItems.Items.Add(strProductName)
                End While
                ' It is used to represent the errors during run-time
                'The message display where the problem might lay
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try

        ElseIf cboGroups.SelectedIndex = 2 Then
            'Selects all the product information from group B
            query = "SELECT * FROM Product_Details_Group_B"
            Try
                'Opens connection
                acc_Record.Open()
                'This variable represents a Sql statement or stored procedure to execute against the datasource
                Dim cmd As OleDbCommand
                'It insures the the sql used gets stored and that the connection is open
                'It executes the command
                cmd = New OleDbCommand(query, acc_Record)
                Dim Reader As OleDbDataReader
                'Executes reader 
                Reader = cmd.ExecuteReader
                'While the reader is running it receives ceratin data from the database table
                While Reader.Read
                    strProductName = Reader.GetString(0)
                    'Adds item names to the combobox
                    cboItems.Items.Add(strProductName)
                End While
                ' It is used to represent the errors during run-time
                'The message display where the problem might lay
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If

    End Sub
End Class